#include "Senior.h"


Senior::Senior(char* id, char* name, char* degree, int sem) :UndergraduateStudent(id, name, degree, sem)
{
	cout << "Senior(char* id, char* name, char* degree, int sem)" << endl;
}


Senior::~Senior()
{
	cout << "~Senior() Destructor" << endl;

}

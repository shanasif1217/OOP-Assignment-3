#pragma once
#include"Student.h"

class GraduateStudent:public Student
{
protected:
	char* StudentType;
public:
	GraduateStudent(char* id = nullptr, char* name = nullptr, char* degree = nullptr, char* stuT = nullptr);
	GraduateStudent(const GraduateStudent& obj);
	GraduateStudent& operator=(const GraduateStudent& obj);

	void display()const;
	~GraduateStudent();
};


#include "Driver.h"


Driver::Driver(char* id, char* name, char* desig) :Staff(id, name,desig)
{
	cout << "Driver(char* id, char* name, char* depart)" << endl;
}

Driver::~Driver()
{
	cout << "~Driver() Destructor" << endl;
	
}

#include "AdministratorTeacher.h"


AdministratorTeacher::AdministratorTeacher(char* id, char* name, char* subject, char* rank) : Teacher(id, name, subject, 0.0), Administrator(id, name, rank), Faculty(id,name,"")
{
	cout << "AdministratorTeacher(char* id, char* name, char* subject, char* rank)" << endl;
}

void AdministratorTeacher::display()const
{
	cout << "ID: " << ID << endl;
	cout << "Name: " << Name << endl;
	cout << "Subject: " << Subject << endl;
	cout << "Rank: " << Rank << endl;
}


AdministratorTeacher::~AdministratorTeacher()
{
	cout << "~AdministratorTeacher() Destructor" << endl;
}

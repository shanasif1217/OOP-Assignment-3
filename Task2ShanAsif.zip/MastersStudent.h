#pragma once
#include"GraduateStudent.h"

class MastersStudent:public GraduateStudent
{
public:
	MastersStudent(char* id = nullptr, char* name = nullptr, char* degree = nullptr, char* stuT = nullptr);
	~MastersStudent();
};


#include "DoctoralStudent.h"


DoctoralStudent::DoctoralStudent(char* id, char* name, char* degree, char* stuT) :GraduateStudent(id,name,degree,stuT)
{
	cout << "DoctoralStudent(char* id, char* name, char* degree, char* stuT)" << endl;
}


DoctoralStudent::~DoctoralStudent()
{
	cout << "~DoctoralStudent() Destructor" << endl;
}

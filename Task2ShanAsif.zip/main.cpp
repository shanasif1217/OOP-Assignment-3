#include"CommunityMember.h"
#include"Employee.h"
#include"Faculty.h"
#include"Administrator.h"
#include"Teacher.h"
#include"AdministratorTeacher.h"
#include"Staff.h"
#include"Driver.h"
#include"Student.h"
#include"UndergraduateStudent.h"
#include"GraduateStudent.h"
#include"Freshman.h"
#include"Sophomore.h"
#include"Junior.h"
#include"Senior.h"
#include"DoctoralStudent.h"
#include"MastersStudent.h"
#include"Alumnus.h"

int main()
{
	cout << "\t\t\t********* CommunityMember Data **********" << endl;
	CommunityMember CM1("L1F21BSCS1255", "Sheraz Khan", 45674356);
	cout << endl;
	CM1.display();
	cout << endl << endl;

	cout << "\t\t\t************* Employee Data *************" << endl;
	Employee E1("EMP34251255", "Ahmad Khan", 45674356,50000.00);
	cout << endl;
	E1.display();
	cout << endl << endl;

	cout << "\t\t\t************* Faculty Data **************" << endl;
	Faculty F1("FOIT2345", "FOIT", "FA202");
	cout << endl;
	F1.display();
	cout << endl << endl;

	cout << "\t\t\t********** Administrator Data ***********" << endl;
	Administrator A1("ADM32456", "Sheraz Khan", "Dean");
	cout << endl;
	A1.display();
	cout << endl << endl;

	cout << "\t\t\t************** Teacher Data *************" << endl;
	Teacher T1("FIT45345", "Bilal Khan", "OOP Theory", 80000.00);
	cout << endl;
	T1.display();
	cout << endl << endl;

	cout << "\t\t\t******* AdministratorTeacher Data *******" << endl;
	AdministratorTeacher AT1("ADMT26345", "Sheraz Khan", "OOP Theory", "Dean");
	AT1.display();
	cout << endl << endl;

	cout << "\t\t\t************** Staff Data ***************" << endl;
	Staff S1("STF446745", "Fahad Khan", "Security Guard");
	cout << endl;
	S1.display();
	cout << endl << endl;

	cout << "\t\t\t************** Driver Data **************" << endl;
	Driver D1("UCPD226745", "Arshad Khan", "Driver");
	cout << endl;
	D1.display();
	cout << endl << endl;

	cout << "\t\t\t************* Student Data **************" << endl;
	Student Stu1("L1F21BSCS1255", "Sheraz Khan", "BSCS",4);
	cout << endl;
	Stu1.display();
	cout << endl << endl;

	cout << "\t\t\t******* UndergraduateStudent Data *******" << endl;
	UndergraduateStudent UGStu1("L1F21BSCS1255", "Sheraz Khan", "BSCS",2);
	cout << endl;
	UGStu1.display();
	cout << endl << endl;

	cout << "\t\t\t********* GraduateStudent Data **********" << endl;
	GraduateStudent GStu1("L1F21MS1255", "Sheraz Khan", "BSCS", "Masters");
	cout << endl;
	GStu1.display();
	cout << endl << endl;

	cout << "\t\t\t************* Freshman Data *************" << endl;
	Freshman FStu1("L1F21BSCS1255", "Sheraz Khan", "BSCS", 1);
	cout << endl;
	FStu1.display();
	cout << endl << endl;

	cout << "\t\t\t************ Sophomore Data *************" << endl;
	Sophomore SStu1("L1F21BSCS1255", "Sheraz Khan", "BSCS", 4);
	cout << endl;
	SStu1.display();
	cout << endl << endl;

	cout << "\t\t\t************** Junior Data **************" << endl;
	Junior JStu1("L1F21BSCS1255", "Sheraz Khan", "BSCS", 6);
	cout << endl;
	JStu1.display();
	cout << endl << endl;

	cout << "\t\t\t************** Senior Data **************" << endl;
	Senior SeniorStu1("L1F21BSCS1255", "Sheraz Khan", "BSCS", 8);
	cout << endl;
	SeniorStu1.display();
	cout << endl << endl;

	cout << "\t\t\t********* DoctoralStudent Data **********" << endl;
	DoctoralStudent DoctoralStu1("L1F21PHD1255", "Sheraz Khan", "Computer Science", "Phd");
	cout << endl;
	DoctoralStu1.display();
	cout << endl << endl;

	cout << "\t\t\t********** MastersStudent Data **********" << endl;
	MastersStudent MasterStu1("L1F22MS1255", "Sheraz Khan", "Computer Science", "Masters");
	cout << endl;
	MasterStu1.display();
	cout << endl << endl;

	cout << "\t\t\t************* Alumnus Data **************" << endl;
	Alumnus AlumnusStu1("L1F22MS1255", "Sheraz Khan", 45674356, 2021);
	cout << endl;
	AlumnusStu1.display();
	cout << endl << endl;

	return 0;
}
#include "Freshman.h"


Freshman::Freshman(char* id, char* name, char* degree, int sem) :UndergraduateStudent(id, name, degree, sem)
{
	cout << "Freshman(char* id, char* name, char* degree, int sem)" << endl;
}


Freshman::~Freshman()
{
	cout << "~Freshman() Destructor" << endl;
}

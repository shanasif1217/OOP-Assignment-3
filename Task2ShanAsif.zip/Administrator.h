#pragma once
#include"Faculty.h"

class Administrator:virtual public Faculty
{
protected:
	char* Rank;
public:
	Administrator(char* id = nullptr, char* name = nullptr, char* rank = nullptr);
	Administrator(const Administrator& obj);
	Administrator& operator=(const Administrator& obj);

	void display()const;
	~Administrator();
};


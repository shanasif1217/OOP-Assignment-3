#pragma once
#include"GraduateStudent.h"

class DoctoralStudent:public GraduateStudent
{
public:
	DoctoralStudent(char* id = nullptr, char* name = nullptr, char* degree = nullptr, char* stuT = nullptr);
	~DoctoralStudent();
};


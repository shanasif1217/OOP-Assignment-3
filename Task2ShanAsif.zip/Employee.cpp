#include "Employee.h"


Employee::Employee(char* id, char* name,long int CP, double salary) :CommunityMember(id,name,CP)
{
	cout << "Employee(char*id, char* name,long int CP, double salary)" << endl;
	Salary = salary;
}

void Employee::display()const
{
	cout << "ID: " << ID << endl;
	cout << "Name: " << Name << endl;
	cout << "CellPhone: " << CellPhone << endl;
	cout << "Salary: Rs." << Salary << endl;
}

Employee::~Employee()
{
	cout << "~Employee() Destructor" << endl;
}

#include "Administrator.h"


Administrator::Administrator(char* id, char* name, char* rank) :Faculty(id,name,"")
{
	cout << "Administrator(char* id, char* name, char* rank)" << endl;
	//For Rank
	int L1 = 0;
	while (true)
	{
		if (rank[L1] == '\0')
			break;
		else
			L1++;
	}

	Rank = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Rank[i] = rank[i];
	}
	Rank[L1] = '\0';
}

Administrator::Administrator(const Administrator& obj)
{
	int L1 = 0;
	while (true)
	{
		if (obj.Rank[L1] == '\0')
			break;
		else
			L1++;
	}

	Rank = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Rank[i] = obj.Rank[i];
	}
	Rank[L1] = '\0';
}

Administrator& Administrator::operator=(const Administrator& obj)
{
	int L1 = 0;
	while (true)
	{
		if (obj.Rank[L1] == '\0')
			break;
		else
			L1++;
	}

	Rank = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Rank[i] = obj.Rank[i];
	}
	Rank[L1] = '\0';

	return *this;
}

void Administrator::display()const
{
	cout << "ID: " << ID << endl;
	cout << "Name: " << Name << endl;
	cout << "Rank: " << Rank << endl;
}

Administrator::~Administrator()
{
	cout << "~Administrator() Destructor" << endl;
	if (Rank != nullptr)
	{
		delete[]Rank;
		Rank = nullptr;
	}
}

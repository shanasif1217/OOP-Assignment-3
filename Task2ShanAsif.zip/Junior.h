#pragma once
#include"UndergraduateStudent.h"

class Junior :public UndergraduateStudent
{
public:
	Junior(char* id = nullptr, char* name = nullptr, char* degree = nullptr, int sem = 0);
	~Junior();
};


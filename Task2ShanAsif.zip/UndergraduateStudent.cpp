#include "UndergraduateStudent.h"


UndergraduateStudent::UndergraduateStudent(char* id, char* name, char* degree, int sem) :Student(id,name,degree,sem)
{
	cout << "UndergraduateStudent(char* id, char* name, char* degree, int sem)" << endl;
}


UndergraduateStudent::~UndergraduateStudent()
{
	cout << "~UndergraduateStudent() Destructor" << endl;
}

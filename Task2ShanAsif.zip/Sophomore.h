#pragma once
#include"UndergraduateStudent.h"

class Sophomore:public UndergraduateStudent
{
public:
	Sophomore(char* id = nullptr, char* name = nullptr, char* degree = nullptr, int sem = 0);
	~Sophomore();
};


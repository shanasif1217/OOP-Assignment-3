#pragma once
#include"Student.h"

class UndergraduateStudent:public Student
{
public:
	UndergraduateStudent(char* id = nullptr, char* name = nullptr, char* degree = nullptr, int sem = 0);
	~UndergraduateStudent();
};


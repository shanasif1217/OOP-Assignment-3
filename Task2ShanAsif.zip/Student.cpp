#include "Student.h"


Student::Student(char* id, char* name, char* degree, int sem) :CommunityMember(id,name,0)
{
	cout << "Student(char* id, char* name, char* degree)" << endl;
	//For DegreeName
	int L1 = 0;
	while (true)
	{
		if (degree[L1] == '\0')
			break;
		else
			L1++;
	}

	DegreeName = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		DegreeName[i] = degree[i];
	}
	DegreeName[L1] = '\0';

	//For Semester
	Semester = sem;
}

Student::Student(const Student& obj)
{
	//For DegreeName
	int L1 = 0;
	while (true)
	{
		if (obj.DegreeName[L1] == '\0')
			break;
		else
			L1++;
	}

	DegreeName = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		DegreeName[i] = obj.DegreeName[i];
	}
	DegreeName[L1] = '\0';

	//For Semester
	Semester = obj.Semester;
}

Student& Student::operator=(const Student& obj)
{
	//For DegreeName
	int L1 = 0;
	while (true)
	{
		if (obj.DegreeName[L1] == '\0')
			break;
		else
			L1++;
	}

	DegreeName = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		DegreeName[i] = obj.DegreeName[i];
	}
	DegreeName[L1] = '\0';

	//For Semester
	Semester = obj.Semester;

	return *this;
}

void Student::display()const
{
	cout << "ID: " << ID << endl;
	cout << "Name: " << Name << endl;
	cout << "Degree Name: " << DegreeName << endl;
	cout << "Semester : " << Semester << endl;
}

Student::~Student()
{
	cout << "~Student() Destructor" << endl;
	if (DegreeName != nullptr)
	{
		delete[]DegreeName;
		DegreeName = nullptr;
	}

}

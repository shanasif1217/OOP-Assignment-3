#include "Alumnus.h"


Alumnus::Alumnus(char* id, char* name, long int CP, int YOG) :CommunityMember(id,name,CP)
{
	cout << "Alumnus(char* id, char* name, long int CP, int YOG)" << endl;
	Year_Of_Graduation = YOG;
}

void Alumnus::display()const
{
	cout << "ID: " << ID << endl;
	cout << "Name: " << Name << endl;
	cout << "CellPhone: " << CellPhone << endl;
	cout << "Year Of Graduation: " << Year_Of_Graduation << endl;
}

Alumnus::~Alumnus()
{
	cout << "~Alumnus() Destructor" << endl;
}

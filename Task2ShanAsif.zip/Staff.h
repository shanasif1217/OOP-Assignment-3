#pragma once
#include"Employee.h"

class Staff:public Employee
{
protected:
	char* Designation;
public:
	Staff(char* id=nullptr, char* name=nullptr,char* desig = nullptr);
	Staff(const Staff& obj);
	Staff& operator=(const Staff& obj);

	void display()const;
	~Staff();
};


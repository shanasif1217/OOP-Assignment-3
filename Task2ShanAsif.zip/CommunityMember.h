#pragma once
#include<iostream>
using namespace std;

class CommunityMember
{
protected:
	char* ID;
	char* Name;
    long int CellPhone;

public:
	CommunityMember(char* id = nullptr, char* name = nullptr, long int CP = 0);
	CommunityMember(const CommunityMember& obj);
	CommunityMember& operator=(const CommunityMember& obj);

	void display()const;
	~CommunityMember();
};


#pragma once
#include"Faculty.h"

class Teacher:virtual public Faculty
{
protected:
	char* Subject;
public:
	Teacher(char* id = nullptr, char* name = nullptr, char* rank = nullptr, double sal = 0.00);
	Teacher(const Teacher& obj);
	Teacher& operator=(const Teacher& obj);

	void display()const;
	~Teacher();
};


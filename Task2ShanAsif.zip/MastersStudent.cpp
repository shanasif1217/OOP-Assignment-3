#include "MastersStudent.h"


MastersStudent::MastersStudent(char* id, char* name, char* degree, char* stuT) :GraduateStudent(id, name, degree, stuT)
{
	cout << "MastersStudent(char* id, char* name, char* degree, char* stuT)" << endl;
}


MastersStudent::~MastersStudent()
{
	cout << "~MastersStudent() Destructor" << endl;
}

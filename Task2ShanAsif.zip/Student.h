#pragma once
#include"CommunityMember.h"

class Student:public CommunityMember
{
protected:
	char* DegreeName;
	int Semester;
public:
	Student(char* id = nullptr, char* name = nullptr, char* degree = nullptr, int sem = 0);
	Student(const Student& obj);
	Student& operator=(const Student& obj);

	void display()const;
	~Student();
};


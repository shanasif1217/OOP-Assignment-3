#pragma once
#include"Staff.h"

class Driver :public Staff
{

public:
	Driver(char* id = nullptr, char* name = nullptr, char* desig = nullptr);
	~Driver();
};


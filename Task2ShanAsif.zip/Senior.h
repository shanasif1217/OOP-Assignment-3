#pragma once
#include"UndergraduateStudent.h"

class Senior :public UndergraduateStudent
{
public:
	Senior(char* id = nullptr, char* name = nullptr, char* degree = nullptr, int sem = 0);
	~Senior();
};


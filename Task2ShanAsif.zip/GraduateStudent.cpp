#include "GraduateStudent.h"


GraduateStudent::GraduateStudent(char* id, char* name, char* degree, char* stuT) :Student(id, name, degree, 0)
{
	cout << "GraduateStudent(char* id, char* name, char* degree, int sem)" << endl;
	//For StudentType
	int L1 = 0;
	while (true)
	{
		if (stuT[L1] == '\0')
			break;
		else
			L1++;
	}
	StudentType = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		StudentType[i] = stuT[i];
	}
	StudentType[L1] = '\0';
}

GraduateStudent::GraduateStudent(const GraduateStudent& obj)
{
	//For StudentType
	int L1 = 0;
	while (true)
	{
		if (obj.StudentType[L1] == '\0')
			break;
		else
			L1++;
	}
	StudentType = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		StudentType[i] = obj.StudentType[i];
	}
	StudentType[L1] = '\0';
}

GraduateStudent& GraduateStudent::operator=(const GraduateStudent& obj)
{
	//For StudentType
	int L1 = 0;
	while (true)
	{
		if (obj.StudentType[L1] == '\0')
			break;
		else
			L1++;
	}
	StudentType = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		StudentType[i] = obj.StudentType[i];
	}
	StudentType[L1] = '\0';

	return *this;
}

void GraduateStudent::display()const
{
	cout << "ID: " << ID << endl;
	cout << "Name: " << Name << endl;
	cout << "Degree Name: " << DegreeName << endl;
	cout << "Student Type : " << StudentType << " Student" << endl;
}

GraduateStudent::~GraduateStudent()
{
	cout << "~GraduateStudent() Destructor" << endl;
	if (StudentType != nullptr)
	{
		delete[]StudentType;
		StudentType = nullptr;
	}
}

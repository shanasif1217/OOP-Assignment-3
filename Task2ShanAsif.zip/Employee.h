#pragma once
#include"CommunityMember.h"

class Employee:public CommunityMember
{
protected:
	double Salary;
public:
	Employee(char* id = nullptr,char* name = nullptr , long int CP = 0, double salary = 0.00);
	void display()const;
	~Employee();
};


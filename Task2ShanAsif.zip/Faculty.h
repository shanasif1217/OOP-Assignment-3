#pragma once
#include"Employee.h"

class Faculty:public Employee
{
private:
	char* FacultyRoomNo;
public:
	Faculty(char* id = nullptr, char* name = nullptr, char * FRNo = nullptr);
	Faculty(const Faculty& obj);
	Faculty& operator=(const Faculty& obj);

	void display()const;
	~Faculty();
};


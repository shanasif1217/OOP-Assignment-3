#include "Faculty.h"


Faculty::Faculty(char*id, char* name, char* FRNo) :Employee(id, name, 0, 0.0)
{
	cout << "Faculty(char*id, char* name, char* FRNo)" << endl;
	//For Facaulty Room No
	int L1 = 0;
	while (true)
	{
		if (FRNo[L1] == '\0')
			break;
		else
			L1++;
	}

	FacultyRoomNo = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		FacultyRoomNo[i] = FRNo[i];
	}
	FacultyRoomNo[L1] = '\0';
}

Faculty::Faculty(const Faculty& obj)
{
	int L1 = 0;
	while (true)
	{
		if (obj.FacultyRoomNo[L1] == '\0')
			break;
		else
			L1++;
	}

	FacultyRoomNo = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		FacultyRoomNo[i] = obj.FacultyRoomNo[i];
	}
	FacultyRoomNo[L1] = '\0';
}

Faculty& Faculty::operator=(const Faculty& obj)
{
	int L1 = 0;
	while (true)
	{
		if (obj.FacultyRoomNo[L1] == '\0')
			break;
		else
			L1++;
	}

	FacultyRoomNo = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		FacultyRoomNo[i] = obj.FacultyRoomNo[i];
	}
	FacultyRoomNo[L1] = '\0';

	return *this;
}

void Faculty::display()const
{
	cout << "ID: " << ID << endl;
	cout << "Name: " << Name << endl;
	cout << "Faculty Room No: " << FacultyRoomNo << endl;
}

Faculty::~Faculty()
{
	cout << "~Faculty() Destructor" << endl;
	if (FacultyRoomNo != nullptr)
	{
		delete[]FacultyRoomNo;
		FacultyRoomNo = nullptr;
	}
}

#pragma once
#include"CommunityMember.h"

class Alumnus:public CommunityMember
{
protected:
	int Year_Of_Graduation;

public:
	Alumnus(char* id = nullptr, char* name = nullptr, long int CP = 0, int YOG = 0);

	void display()const;
	~Alumnus();
};


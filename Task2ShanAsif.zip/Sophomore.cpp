#include "Sophomore.h"


Sophomore::Sophomore(char* id, char* name, char* degree, int sem) :UndergraduateStudent(id, name, degree, sem)
{
	cout << "Sophomore(char* id, char* name, char* degree, int sem)" << endl;
}


Sophomore::~Sophomore()
{
	cout << "~Sophomore() Destructor" << endl;
}

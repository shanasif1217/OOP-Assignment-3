#pragma once

#include"Administrator.h"
#include"Teacher.h"

class AdministratorTeacher:public Administrator , public Teacher
{
public:
	AdministratorTeacher(char* id = nullptr, char* name = nullptr, char* subject = nullptr, char* rank = nullptr);
	void display()const;
	~AdministratorTeacher();
};


#include "Junior.h"


Junior::Junior(char* id, char* name, char* degree, int sem) :UndergraduateStudent(id, name, degree, sem)
{
	cout << "Junior(char* id, char* name, char* degree, int sem)" << endl;
}


Junior::~Junior()
{
	cout << "~Junior() Destructor" << endl;
}

#include "CommunityMember.h"


CommunityMember::CommunityMember(char* id, char* name, long int CP)
{
	cout << "CommunityMember(char* id, char* name, long int CP)" << endl;
	//For id
	int L1 = 0;
	while (true)
	{
		if (id[L1] == '\0')
			break;
		else
			L1++;
	}
	ID = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		ID[i] = id[i];
	}
	ID[L1] = '\0';

	//For Name
	int L2 = 0;
	while (true)
	{
		if (name[L2] == '\0')
			break;
		else
			L2++;
	}

	Name = new char[L2 + 1];

	for (int i = 0; i < L2; i++)
	{
		Name[i] = name[i];
	}
	Name[L2] = '\0';

	//For CellPhone

	CellPhone = CP;

}

CommunityMember::CommunityMember(const CommunityMember& obj)
{
	//For id
	int L1 = 0;
	while (true)
	{
		if (obj.ID[L1] == '\0')
			break;
		else
			L1++;
	}

	ID = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		ID[i] = obj.ID[i];
	}
	ID[L1] = '\0';

	//For Name
	int L2 = 0;
	while (true)
	{
		if (obj.Name[L2] == '\0')
			break;
		else
			L2++;
	}

	Name = new char[L2 + 1];

	for (int i = 0; i < L2; i++)
	{
		Name[i] = obj.Name[i];
	}
	Name[L2] = '\0';

	//For CellPhone

	CellPhone = obj.CellPhone;

}

CommunityMember& CommunityMember::operator=(const CommunityMember& obj)
{
	//For id
	int L1 = 0;
	while (true)
	{
		if (obj.ID[L1] == '\0')
			break;
		else
			L1++;
	}

	ID = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		ID[i] = obj.ID[i];
	}
	ID[L1] = '\0';

	//For Name
	int L2 = 0;
	while (true)
	{
		if (obj.Name[L2] == '\0')
			break;
		else
			L2++;
	}

	Name = new char[L2 + 1];

	for (int i = 0; i < L2; i++)
	{
		Name[i] = obj.Name[i];
	}
	Name[L2] = '\0';

	//For CellPhone

	CellPhone = obj.CellPhone;

	return *this;
}

void CommunityMember::display()const
{
	cout << "ID: " << ID << endl;
	cout << "Name: " << Name << endl;
	cout << "CellPhone: " << CellPhone << endl;
}

CommunityMember::~CommunityMember()
{
	cout << "~CommunityMember() Destructor" << endl;
	if (ID != nullptr)
	{
		delete[]ID;
		ID = nullptr;
	}
	if (Name != nullptr)
	{
		delete[]Name;
		Name = nullptr;
	}
}

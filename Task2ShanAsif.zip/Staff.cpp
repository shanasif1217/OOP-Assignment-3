#include "Staff.h"


Staff::Staff(char* id, char* name, char* desig) :Employee(id,name,0,0.0)
{
	cout << "Staff(char* id, char* name, char* desig)" << endl;
	//For Designation
	int L1 = 0;
	while (true)
	{
		if (desig[L1] == '\0')
			break;
		else
			L1++;
	}

	Designation = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Designation[i] = desig[i];
	}
	Designation[L1] = '\0';
}

Staff::Staff(const Staff& obj)
{
	int L1 = 0;
	while (true)
	{
		if (obj.Designation[L1] == '\0')
			break;
		else
			L1++;
	}

	Designation = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Designation[i] = obj.Designation[i];
	}
	Designation[L1] = '\0';
}

Staff& Staff::operator=(const Staff& obj)
{
	int L1 = 0;
	while (true)
	{
		if (obj.Designation[L1] == '\0')
			break;
		else
			L1++;
	}

	Designation = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Designation[i] = obj.Designation[i];
	}
	Designation[L1] = '\0';

	return *this;
}

void Staff::display()const
{
	cout << "ID: " << ID << endl;
	cout << "Name: " << Name << endl;
	cout << "Designation: " << Designation << endl;
}

Staff::~Staff()
{
	cout << "~Staff() Destructor" << endl;
	if (Designation != nullptr)
	{
		delete[]Designation;
		Designation = nullptr;
	}
}

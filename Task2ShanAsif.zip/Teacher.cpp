#include "Teacher.h"


Teacher::Teacher(char* id, char* name, char* subject, double sal) :Faculty(id, name, "")
{
	cout << "Teacher(char* id, char* name, char* subject)" << endl;
	//For Subject
	int L1 = 0;
	while (true)
	{
		if (subject[L1] == '\0')
			break;
		else
			L1++;
	}

	Subject = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Subject[i] = subject[i];
	}
	Subject[L1] = '\0';

	//For Salary
	Salary = sal;

}

Teacher::Teacher(const Teacher& obj)
{
	//For Subject
	int L1 = 0;
	while (true)
	{
		if (obj.Subject[L1] == '\0')
			break;
		else
			L1++;
	}

	Subject = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Subject[i] = obj.Subject[i];
	}
	Subject[L1] = '\0';

	//For Salary
	Salary = obj.Salary;
	
}

Teacher& Teacher::operator=(const Teacher& obj)
{
	//For Subject
	int L1 = 0;
	while (true)
	{
		if (obj.Subject[L1] == '\0')
			break;
		else
			L1++;
	}

	Subject = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Subject[i] = obj.Subject[i];
	}
	Subject[L1] = '\0';

	//For Salary
	Salary = obj.Salary;

	return *this;
}

void Teacher::display()const
{
	cout << "ID: " << ID << endl;
	cout << "Name: " << Name << endl;
	cout << "Subject: " << Subject << endl;
	cout << "Salary: Rs." << Salary << endl;
}


Teacher::~Teacher()
{
	cout << "~Teacher() Destructor" << endl;

	if (Subject != nullptr)
	{
		delete[]Subject;
		Subject = nullptr;
	}
}

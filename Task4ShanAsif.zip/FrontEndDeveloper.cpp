#include "FrontEndDeveloper.h"


FrontEndDeveloper::FrontEndDeveloper(char* name, char* email, char* edu, long int CPhnNo) :WebDeveloper(name,email,edu,CPhnNo)
{
	cout << "FrontEndDeveloper(char* name, char* email, char* edu, long int CPhnNo)" << endl;
}


FrontEndDeveloper::~FrontEndDeveloper()
{
	cout << "~FrontEndDeveloper()" << endl;
}

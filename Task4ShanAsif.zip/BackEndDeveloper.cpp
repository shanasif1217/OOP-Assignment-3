#include "BackEndDeveloper.h"


BackEndDeveloper::BackEndDeveloper(char* name, char* email, char* edu, long int CPhnNo) :WebDeveloper(name, email, edu, CPhnNo)
{
	cout << "BackEndDeveloper(char* name, char* email, char* edu, long int CPhnNo)" << endl;
}


BackEndDeveloper::~BackEndDeveloper()
{
	cout << "~BackEndDeveloper()" << endl;
}

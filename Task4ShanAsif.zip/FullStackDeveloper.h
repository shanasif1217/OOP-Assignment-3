#pragma once
#include"FrontEndDeveloper.h"
#include"BackEndDeveloper.h"

class FullStackDeveloper:public FrontEndDeveloper, public BackEndDeveloper
{
public:
	FullStackDeveloper(char* name = nullptr, char* email = nullptr, char* edu = nullptr, long int CPhnNo = 0);
	~FullStackDeveloper();
};


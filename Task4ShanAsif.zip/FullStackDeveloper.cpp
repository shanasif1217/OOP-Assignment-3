#include "FullStackDeveloper.h"


FullStackDeveloper::FullStackDeveloper(char* name, char* email, char* edu, long int CPhnNo) :WebDeveloper(name, email, edu, CPhnNo)
{
	cout << "FullStackDeveloper(char* name, char* email, char* edu, long int CPhnNo)" << endl;
}


FullStackDeveloper::~FullStackDeveloper()
{
	cout << "~FullStackDeveloper()" << endl;
}

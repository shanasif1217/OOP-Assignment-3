#include"FullStackDeveloper.h"

int main()
{
	/*WebDeveloper WD("Sheraz Khan", "sherazkhan123@gmail.com", "BSCS", 34567892);
	cout << endl;
	WD.display();
	cout << endl << endl;

	FrontEndDeveloper FED("Sheraz Khan", "sherazkhan123@gmail.com", "BSCS", 34567892);
	cout << endl;
	FED.display();
	cout << endl << endl;

	BackEndDeveloper BED("Sheraz Khan", "sherazkhan123@gmail.com", "BSSE", 34567892);
	cout << endl;
	BED.display();
	cout << endl << endl;*/

	FullStackDeveloper FSD("Sheraz Khan", "sherazkhan123@gmail.com", "BSCS", 34567892);
	cout << endl;
	FSD.display();
	cout << endl << endl;

	return 0;
}
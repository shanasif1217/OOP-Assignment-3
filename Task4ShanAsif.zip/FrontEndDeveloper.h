#pragma once
#include"WebDeveloper.h"

class FrontEndDeveloper:virtual public WebDeveloper
{
public:
	FrontEndDeveloper(char* name = nullptr, char* email = nullptr, char* edu = nullptr, long int CPhnNo = 0);
	~FrontEndDeveloper();
};


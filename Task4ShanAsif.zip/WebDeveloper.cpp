#include "WebDeveloper.h"


WebDeveloper::WebDeveloper(char* name, char* email, char* edu, long int CPhnNo)
{
	cout << "WebDeveloper(char* name, char* email, char* edu, long int CPhnNo)" << endl;

	//For Name
	int L1 = 0;
	while (true)
	{
		if (name[L1] == '\0')
			break;
		else
			L1++;
	}
	Name = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Name[i] = name[i];
	}
	Name[L1] = '\0';

	//For Email
	int L2 = 0;
	while (true)
	{
		if (email[L2] == '\0')
			break;
		else
			L2++;
	}
	Email = new char[L2 + 1];

	for (int i = 0; i < L2; i++)
	{
		Email[i] = email[i];
	}
	Email[L2] = '\0';

	//For Education
	int L3 = 0;
	while (true)
	{
		if (edu[L3] == '\0')
			break;
		else
			L3++;
	}
	Education = new char[L3 + 1];

	for (int i = 0; i < L3; i++)
	{
		Education[i] = edu[i];
	}
	Education[L3] = '\0';

	//For CellPhone
	CellPhone = CPhnNo;

}

WebDeveloper::WebDeveloper(const WebDeveloper& obj)
{
	//For Name
	int L1 = 0;
	while (true)
	{
		if (obj.Name[L1] == '\0')
			break;
		else
			L1++;
	}
	Name = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Name[i] = obj.Name[i];
	}
	Name[L1] = '\0';

	//For Email
	int L2 = 0;
	while (true)
	{
		if (obj.Email[L2] == '\0')
			break;
		else
			L2++;
	}
	Email = new char[L2 + 1];

	for (int i = 0; i < L2; i++)
	{
		Email[i] = obj.Email[i];
	}
	Email[L2] = '\0';

	//For Education
	int L3 = 0;
	while (true)
	{
		if (obj.Education[L3] == '\0')
			break;
		else
			L3++;
	}
	Education = new char[L3 + 1];

	for (int i = 0; i < L3; i++)
	{
		Education[i] = obj.Education[i];
	}
	Education[L3] = '\0';

	//For CellPhone
	CellPhone = obj.CellPhone;
}

WebDeveloper& WebDeveloper::operator = (const WebDeveloper& obj)
{
	//For Name
	int L1 = 0;
	while (true)
	{
		if (obj.Name[L1] == '\0')
			break;
		else
			L1++;
	}
	Name = new char[L1 + 1];

	for (int i = 0; i < L1; i++)
	{
		Name[i] = obj.Name[i];
	}
	Name[L1] = '\0';

	//For Email
	int L2 = 0;
	while (true)
	{
		if (obj.Email[L2] == '\0')
			break;
		else
			L2++;
	}
	Email = new char[L2 + 1];

	for (int i = 0; i < L2; i++)
	{
		Email[i] = obj.Email[i];
	}
	Email[L2] = '\0';

	//For Education
	int L3 = 0;
	while (true)
	{
		if (obj.Education[L3] == '\0')
			break;
		else
			L3++;
	}
	Education = new char[L3 + 1];

	for (int i = 0; i < L3; i++)
	{
		Education[i] = obj.Education[i];
	}
	Education[L3] = '\0';

	//For CellPhone
	CellPhone = obj.CellPhone;

	return *this;
}

void WebDeveloper::display()const
{
	cout << "Name: " << Name << endl;
	cout << "Email Address: " << Email << endl;
	cout << "Education: " << Education << endl;
	cout << "Cell Phone: " << CellPhone << endl;
}

WebDeveloper::~WebDeveloper()
{
	cout << "~WebDeveloper()" << endl;
	if (Name != nullptr)
	{
		delete[]Name;
		Name = nullptr;
	}

	if (Email != nullptr)
	{
		delete[]Email;
		Email = nullptr;
	}

	if (Education != nullptr)
	{
		delete[]Education;
		Education = nullptr;
	}
}

#pragma once
#pragma once
#include<iostream>
using namespace std;

class WebDeveloper
{
protected:
	char* Name;
	char* Email;
	char* Education;
	long int CellPhone;
public:
	WebDeveloper(char* name = nullptr, char* email = nullptr, char* edu = nullptr, long int CPhnNo = 0);
	WebDeveloper(const WebDeveloper& obj);
	WebDeveloper& operator=(const WebDeveloper& obj);

	void display()const;
	~WebDeveloper();
};


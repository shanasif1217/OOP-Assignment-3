#pragma once
#include"WebDeveloper.h"

class BackEndDeveloper:virtual public WebDeveloper
{
public:
	BackEndDeveloper(char* name = nullptr, char* email = nullptr, char* edu = nullptr, long int CPhnNo = 0);
	~BackEndDeveloper();
};


#pragma once
#include"TwoDimensionalShape.h"
class Circle:public TwoDimensionalShape
{
private:
	const double pi;
public:
	Circle(double r=1);
	double area()const;
	void display()const;

	~Circle();
};


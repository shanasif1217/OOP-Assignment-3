#include "Tetrahedron.h"


Tetrahedron::Tetrahedron(double s) :ThreeDimensionalShape(s,0,0,0)
{
	cout << "Tetrahedron(double s)" << endl;
}

double Tetrahedron::volume()const
{
	return length*length*length / (6*1.414);
}

void Tetrahedron::display()const
{
	cout << "Side Length Of Tetrahedron: " << length << endl;
}

Tetrahedron::~Tetrahedron()
{
	cout << "~Tetrahedron() Destructor" << endl;
}

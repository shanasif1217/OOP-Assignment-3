#include "Square.h"


Square::Square(double s) :TwoDimensionalShape(s,s,0,0)
{
	cout << "Square(double s)" << endl;
}

void Square::display()const
{
	cout << "Side of Square: " << length << endl;
}
Square::~Square()
{
	cout << "~Square() Destructor" << endl;
}

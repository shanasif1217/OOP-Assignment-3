#pragma once
#include"TwoDimensionalShape.h"

class Rectangle: public TwoDimensionalShape
{
public:
	Rectangle(double l = 1, double w = 1);
	void display()const;
	~Rectangle();
};


#include "ThreeDimensionalShape.h"


ThreeDimensionalShape::ThreeDimensionalShape(double l, double w, double h, double r) :Shape(l,w,h,r)
{
	cout << "ThreeDimensionalShape(double l, double w, double h, double r)" << endl;
}

double ThreeDimensionalShape::volume()const
{
	return length*width*height;
}

ThreeDimensionalShape::~ThreeDimensionalShape()
{
	cout << "~ThreeDimensionalShape() Destructor" << endl;
}

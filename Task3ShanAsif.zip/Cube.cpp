#include "Cube.h"


Cube::Cube(double l, double w, double h) :ThreeDimensionalShape(l,w,h,0)
{
	cout << "Cube(double l, double w, double h)" << endl;
}

void Cube::display()const
{
	cout << "Length Of Cube: " << length << endl;
	cout << "Width Of Cube: " << width << endl;
	cout << "Height Of Cube: " << height << endl;
	
}

Cube::~Cube()
{
	cout << "~Cube() Destructor" << endl;
}

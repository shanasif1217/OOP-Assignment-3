#pragma once
#include"TwoDimensionalShape.h"
class Triangle:public TwoDimensionalShape
{
public:
	Triangle(double w, double h);
	double area()const;
	void display()const;

	~Triangle();
};


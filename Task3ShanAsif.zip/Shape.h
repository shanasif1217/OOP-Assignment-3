#pragma once
#include<iostream>
using namespace std;

class Shape
{
protected:
	double length;
	double width;
	double height;
	double radius;

public:
	Shape(double l = 1, double w = 1, double h = 1, double r = 1);

	void display()const;
	~Shape();
};


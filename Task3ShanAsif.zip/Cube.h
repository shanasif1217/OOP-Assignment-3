#pragma once
#include"ThreeDimensionalShape.h"

class Cube:public ThreeDimensionalShape
{
public:
	Cube(double l, double w, double h);
	void display()const;
	~Cube();
};


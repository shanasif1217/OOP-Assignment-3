#include"Shape.h"
#include"Rectangle.h"
#include"Square.h"
#include"Triangle.h"
#include"Circle.h"
#include"Sphere.h"
#include"Cube.h"
#include"Tetrahedron.h"

int main()
{
	cout << "\t\t\t**********************************************" << endl;
	cout << "\t\t\t******* Area Of Two Dimensional Shapes *******" << endl;
	cout << "\t\t\t**********************************************" << endl << endl;

	cout << "\t\t\t\t******************************" << endl;
	cout << "\t\t\t\t********** Rectangle *********" << endl;
	cout << "\t\t\t\t******************************" << endl << endl;
	Rectangle R1(4, 6);
	cout << endl;
	R1.display();
	cout << "Area Of Reactangle: " << R1.area() << endl;

	cout << "\t\t\t\t******************************" << endl;
	cout << "\t\t\t\t*********** Square ***********" << endl;
	cout << "\t\t\t\t******************************" << endl << endl;
	Square S1(3);
	cout << endl;
	S1.display();
	cout << "Area Of Square: " << S1.area() << endl;

	cout << "\t\t\t\t******************************" << endl;
	cout << "\t\t\t\t********** Triangle **********" << endl;
	cout << "\t\t\t\t******************************" << endl << endl;
	Triangle T1(4,5);
	cout << endl;
	T1.display();
	cout << "Area Of Triangle: " << T1.area() << endl;

	cout << "\t\t\t\t******************************" << endl;
	cout << "\t\t\t\t*********** Circle ***********" << endl;
	cout << "\t\t\t\t******************************" << endl << endl;
	Circle C1(4);
	cout << endl;
	C1.display();
	cout << "Area Of Circle: " << C1.area() << endl;

	cout << "\t\t\t**********************************************" << endl;
	cout << "\t\t\t***** Volume Of Three Dimensional Shapes *****" << endl;
	cout << "\t\t\t**********************************************" << endl << endl;

	cout << "\t\t\t\t******************************" << endl;
	cout << "\t\t\t\t*********** Sphere ***********" << endl;
	cout << "\t\t\t\t******************************" << endl << endl;
	Sphere Sp1(5);
	cout << endl;
	Sp1.display();
	cout << "Volume Of Sphere: " << Sp1.volume() << endl;

	cout << "\t\t\t\t******************************" << endl;
	cout << "\t\t\t\t************ Cube ************" << endl;
	cout << "\t\t\t\t******************************" << endl << endl;
	Cube Cu1(2, 4, 6);
	cout << endl;
	Cu1.display();
	cout << "Volume Of Cube: " << Cu1.volume() << endl;

	cout << "\t\t\t\t******************************" << endl;
	cout << "\t\t\t\t******** Tetrahedron *********" << endl;
	cout << "\t\t\t\t******************************" << endl << endl;
	Tetrahedron Te1(5);
	cout << endl;
	Te1.display();
	cout << "Volume Of Tetrahedron: " << Te1.volume() << endl;
	
	cout << endl;
	cout << "\t\t\t**********************************************" << endl;
	cout << "\t\t\t**************** Destructors *****************" << endl;
	cout << "\t\t\t**********************************************" << endl << endl;
	
	return 0;
}
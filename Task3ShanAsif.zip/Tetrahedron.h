#pragma once
#include"ThreeDimensionalShape.h"

class Tetrahedron:public ThreeDimensionalShape
{
public:
	Tetrahedron(double s = 1);
	double volume()const;
	void display()const;

	~Tetrahedron();
};


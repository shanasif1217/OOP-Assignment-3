#pragma once
#include"TwoDimensionalShape.h"
class Square:public TwoDimensionalShape
{
public:
	Square(double s = 1);
	void display()const;
	~Square();
};


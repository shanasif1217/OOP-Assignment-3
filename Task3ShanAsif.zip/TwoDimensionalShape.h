#pragma once
#include"Shape.h"

class TwoDimensionalShape :public Shape
{
public:
	TwoDimensionalShape(double l = 1, double w = 1, double h = 1, double r = 1);
	double area()const;

	~TwoDimensionalShape();
};


#include "Triangle.h"


Triangle::Triangle(double w, double h) :TwoDimensionalShape(0,w,h,0)
{
	cout << "Triangle(double w, double h)" << endl;
}

double Triangle::area()const
{
	return 1 / 2.0*width*height;
}

void Triangle::display()const
{
	cout << "Width Of Triangle: " << width << endl;
	cout << "Height Of Triangle: " << height << endl;
}

Triangle::~Triangle()
{
	cout << "~Triangle() Destructor" << endl;
}

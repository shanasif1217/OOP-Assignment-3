#include "TwoDimensionalShape.h"


TwoDimensionalShape::TwoDimensionalShape(double l, double w, double h, double r) :Shape(l,w,h,r)
{
	cout << "TwoDimensionalShape(double l, double w, double h, double r)" << endl;
}

double TwoDimensionalShape::area()const
{
	return length*width;
}

TwoDimensionalShape::~TwoDimensionalShape()
{
	cout << "~TwoDimensionalShape() Destructor" << endl;
}

#pragma once
#include"ThreeDimensionalShape.h"

class Sphere:public ThreeDimensionalShape
{
private:
	const double pi;
public:
	Sphere(double r = 1);
	double volume()const;
	void display()const;

	~Sphere();
};


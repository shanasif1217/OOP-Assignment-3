#include "Circle.h"

Circle::Circle(double r) : pi(3.14), TwoDimensionalShape(0, 0, 0, r)
{
	cout << "Circle(double r)" << endl;
}

double Circle::area()const
{
	return pi*radius*radius;
}

void Circle::display()const
{
	cout << "Radius Of Circle: " << radius << endl;
}

Circle::~Circle()
{
	cout << "~Circle() Destructor" << endl;
}

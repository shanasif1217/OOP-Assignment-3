#include "Shape.h"


Shape::Shape(double l, double w, double h, double r)
{
	cout << "Shape(double l, double w, double h, double r)" << endl;
	length = l;
	width = w;
	height = h;
	radius = r;
}

void Shape::display()const
{
	cout << "Length: " << length << endl;
	cout << "Width: " << width << endl;
	cout << "Height: " << height << endl;
	cout << "Radius: " << radius << endl;
}

Shape::~Shape()
{
	cout << "~Shape() Destructor" << endl;
}

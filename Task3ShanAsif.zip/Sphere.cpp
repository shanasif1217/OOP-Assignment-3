#include "Sphere.h"


Sphere::Sphere(double r) :pi(3.14) , ThreeDimensionalShape(0,0,0,r)
{
	cout << "Sphere(double r)" << endl;
}

double Sphere::volume()const
{
	return 4 / 3.0 * pi*radius*radius*radius;
}

void Sphere::display()const
{
	cout << "Radius Of Sphere: " << radius << endl;
}

Sphere::~Sphere()
{
	cout << "~Sphere() Destructor" << endl;
}

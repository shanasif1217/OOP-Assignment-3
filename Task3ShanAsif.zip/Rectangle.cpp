#include "Rectangle.h"


Rectangle::Rectangle(double l, double w) :TwoDimensionalShape(l, w, 0, 0)
{
	cout << "Rectangle(double l, double w)" << endl;
}

void Rectangle::display()const
{
	cout << "Length of Rectangle: " << length << endl;
	cout << "Width of Rectangle: " << width << endl;
}

Rectangle::~Rectangle()
{
	cout << "~Rectangle() Destructor" << endl;
}

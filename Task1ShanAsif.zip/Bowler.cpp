#include "Bowler.h"


Bowler::Bowler(int w) :Player("M Amir",3)
{
	cout << "Bowler(int w)" << endl;
	No_Of_Wickets = w;
}

void Bowler::display()const
{
	cout << "Total Wickets in " << Matches << " Matches: " << No_Of_Wickets << endl;
}


Bowler::~Bowler()
{
	cout << "~Bowler() Destructor" << endl;
}

#pragma once
#include"Player.h"

class Bowler:public Player
{
private:
	int No_Of_Wickets;
public:
	Bowler(int W = 0);
	void display()const;
	~Bowler();
};


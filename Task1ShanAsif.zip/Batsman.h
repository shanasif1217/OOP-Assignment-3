#pragma once
#include"Player.h"

class Batsman:public Player
{
private:
	int Total_score;
	int* Per_match_score;
	double Average;

public:
	Batsman(int TS = 0, int* PMS = nullptr, double A = 0.0);
	Batsman(const Batsman& obj);
	Batsman& operator=(const Batsman& obj);

	void set_Score(int* s);
	double Cal_Average(int* pms);
	void display()const;
	~Batsman();
};


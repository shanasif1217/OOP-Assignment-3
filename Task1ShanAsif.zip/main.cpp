#include"Player.h"
#include"Batsman.h"
#include"Bowler.h"

int main()
{
	cout << "\t\t\t*****************************" << endl;
	cout << "\t\t\t********** Batsman **********" << endl;
	cout << "\t\t\t*****************************" << endl << endl;

	int arr[3] = { 20, 40, 40 };//Matches array
	Batsman SA(0,arr,0);
	SA.set_Score(arr); 
	SA.Cal_Average(arr);
	cout << endl;
	SA.Player::display();
	SA.display();

	cout << endl << endl;

	cout << "\t\t\t*****************************" << endl;
	cout << "\t\t\t********** Bowler ***********" << endl;
	cout << "\t\t\t*****************************" << endl << endl;
	
	Bowler MA(6);
	cout << endl;
	MA.Player::display();
	MA.display();

	cout << endl << endl;

	return 0;
}
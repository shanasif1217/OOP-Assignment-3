#include "Batsman.h"


Batsman::Batsman(int TS, int* PMS, double A) :Player("Shahid Afridi",3)
{
	cout << "Batsman(int TS, int* PMS, double A)" << endl;
	Total_score = TS;

	Per_match_score = new int[Matches];
	for (int i = 0; i < Matches; i++)
	{
		Per_match_score[i] = PMS[i];
	}

	Average = A;
}

Batsman::Batsman(const Batsman& obj) 
{
	Total_score = obj.Total_score;

	Per_match_score = new int[obj.Matches];
	for (int i = 0; i < Matches; i++)
	{
		Per_match_score[i] = obj.Per_match_score[i];
	}

	Average = obj.Average;
}

Batsman& Batsman::operator=(const Batsman& obj)
{
	Total_score = obj.Total_score;

	Per_match_score = new int[obj.Matches]; 
	for (int i = 0; i < Matches; i++)
	{
		Per_match_score[i] = obj.Per_match_score[i];
	}

	Average = obj.Average;

	return *this;

}

double Batsman::Cal_Average(int* pms)
{
	double Avg = 0;
	for (int i = 0; i < Matches; i++)
	{
		Avg = Avg + pms[i];
		
	}
	Avg = Avg / Matches;
	Average = Avg;
	return Avg;
}

void Batsman::display()const
{
	cout << "Total Score: " << Total_score << endl;
	for (int i = 0; i < Matches; i++)
	{
		cout << "Match " << i + 1 << " score: " << Per_match_score[i] << endl;
	}
	cout << "Average: " << Average << endl;
}

void Batsman::set_Score(int *s)
{
	Total_score = 0;
	for (int i = 0; i < Matches; i++)
	{
		Total_score = Total_score + Per_match_score[i];
	}
}

Batsman::~Batsman()
{
	cout << "~Batsman() Destructor" << endl;
	delete[]Per_match_score;
	Per_match_score = nullptr;
	
}

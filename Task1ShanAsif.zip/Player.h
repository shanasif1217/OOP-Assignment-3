#pragma once
#pragma once
#include<iostream>
using namespace std;

class Player
{
protected:
	char* Name;
	int Matches;
public:
	Player(char* n = nullptr, int m = 0);
	Player(const Player& obj);
	Player& operator=(const Player& obj);
	void display()const;
	~Player();
};


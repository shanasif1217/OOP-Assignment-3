#include "Player.h"


Player::Player(char* n, int m)
{
	cout << "Player(char* n, int m)" << endl;
	int Length = 0;
	while (true)
	{
		if (n[Length] == '\0')
			break;
		else
			Length++;
	}
	Name = new char[Length + 1];
	for (int i = 0; i < Length; i++)
	{
		Name[i] = n[i];
	}
	Name[Length] = '\0';

	Matches = m;
}

Player::Player(const Player& obj)
{
	int Length = 0;
	while (true)
	{
		if (obj.Name[Length] == '\0')
			break;
		else
			Length++;
	}
	Name = new char[Length + 1];
	for (int i = 0; i < Length; i++)
	{
		Name[i] = obj.Name[i];
	}
	Name[Length] = '\0';

	Matches = obj.Matches;
}

Player& Player::operator=(const Player& obj)
{
	int Length = 0;
	while (true)
	{
		if (obj.Name[Length] == '\0')
			break;
		else
			Length++;
	}
	Name = new char[Length + 1];
	for (int i = 0; i < Length; i++)
	{
		Name[i] = obj.Name[i];
	}
	Name[Length] = '\0';

	Matches = obj.Matches;

	return *this;
}

void Player::display()const
{
	cout << "Name of Player: " << Name << endl;
	cout << "Total Number of Matches Played: " << Matches << endl;
}

Player::~Player()
{
	cout << "~Player() Destructor" << endl;
	delete Name;
	Name = nullptr;

}
